from flask import Flask, render_template, request, send_file, session, redirect, url_for, after_this_request
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import io
import os
import comtypes.client
from datetime import datetime
from comtypes import CoInitialize
from time import sleep

app = Flask(__name__)
app.secret_key = "secret_key"  
UPLOAD_FOLDER = 'uploads'
TEMPLATE_FOLDER = 'templates'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ketua_tim_list = []

# Fungsi untuk mengubah format tanggal menjadi '12 Maret 2023'
def format_tanggal(tanggal_str):
    try:
        dt = datetime.strptime(tanggal_str, '%Y-%m-%d')
        return dt.strftime('%d %B %Y')
    except ValueError:
        return tanggal_str

# Fungsi untuk mengubah periode menjadi '12 s.d 15 Maret 2023'
def format_periode(periode_awal, periode_akhir):
    try:
        start = datetime.strptime(periode_awal, '%Y-%m-%d')
        end = datetime.strptime(periode_akhir, '%Y-%m-%d')
        if start.month == end.month and start.year == end.year:
            return f"{start.day} s.d {end.day} {start.strftime('%B %Y')}"
        return f"{start.strftime('%d %B %Y')} s.d {end.strftime('%d %B %Y')}"
    except ValueError:
        return f"{periode_awal} s.d {periode_akhir}"

# Fungsi validasi tanggal kegiatan dalam rentang periode penugasan
def validate_tanggal_kegiatan(tanggal_kegiatan, periode_awal, periode_akhir):
    try:
        tanggal = datetime.strptime(tanggal_kegiatan, '%Y-%m-%d')
        start_date = datetime.strptime(periode_awal, '%Y-%m-%d')
        end_date = datetime.strptime(periode_akhir, '%Y-%m-%d')
        return start_date <= tanggal <= end_date
    except ValueError:
        return False  

# Fungsi untuk menghapus baris kosong di tabel Word
def remove_empty_rows(doc):
    for table in doc.tables:
        rows_to_remove = [row for row in table.rows if all(cell.text.strip() == "" for cell in row.cells)]
        for row in rows_to_remove:
            table._tbl.remove(row._tr)

@app.route('/')
def home():
    session.setdefault("gambar_count", 1)
    return render_template("index.html", gambar_count=session["gambar_count"])

@app.route('/generate', methods=['POST'])
def generate():
    ketua_tim = request.form.get('ketua_tim', '')
    petugas = request.form.get('petugas', '')
    tanggal_laporan = request.form.get('tanggal_laporan', '')
    lokasi = request.form.get('lokasi', '')
    periode_awal = (request.form.get('periode_mulai') or '').strip()
    periode_akhir = (request.form.get('periode_selesai') or '').strip()
    nomor_surat = request.form['nomor_surat']
    tanggal_surat = request.form['tanggal_surat']
    nama_petugas = request.form['nama_petugas'].strip().replace(" ", "_")
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    word_output_path = os.path.join(UPLOAD_FOLDER, f"Laporan_{nama_petugas}_{timestamp}.docx")
    pdf_output_path = word_output_path.replace(".docx", ".pdf")
    template_path = os.path.join(TEMPLATE_FOLDER, 'template.docx')
    
    if not os.path.exists(template_path):
        return "Template tidak ditemukan."
    
    doc = Document(template_path)
    tanggal_kegiatan_list = request.form.getlist('tanggal_kegiatan[]')
    uraian_kegiatan_list = request.form.getlist('uraian_kegiatan[]')
    
    valid_tanggal_kegiatan = [t for t in tanggal_kegiatan_list if validate_tanggal_kegiatan(t, periode_awal, periode_akhir)]
    if len(valid_tanggal_kegiatan) != len(tanggal_kegiatan_list):
        return "Beberapa tanggal kegiatan tidak valid dalam periode penugasan."
    # Tambahkan gambar untuk setiap kegiatan
    for i in range(len(tanggal_kegiatan_list)):
        gambar_list = request.files.getlist(f'gambar_kegiatan_{i}[]')  # Dapatkan semua gambar untuk kegiatan ini
        if gambar_list:
            doc.add_paragraph(f"Dokumentasi untuk Kegiatan pada Tanggal {tanggal_kegiatan_list[i]}:").alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            for gambar in gambar_list:
                if gambar.filename != '':
                    gambar_bytes = gambar.read()  # Membaca gambar sebagai byte stream
                    image_stream = io.BytesIO(gambar_bytes)  # Mengonversi byte stream ke objek file-like
                    
                    # Menambahkan gambar ke dalam dokumen
                    paragraph = doc.add_paragraph()
                    paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER  # Ratakan ke tengah setiap gambar
                    run = paragraph.add_run()
                    run.add_picture(image_stream, width=Inches(5))  # Ukuran gambar disesuaikan


    for table in doc.tables:
        if 'Nomor Surat Tugas' in table.rows[0].cells[0].text:
            for row in table.rows:
                if 'Nomor Surat Tugas' in row.cells[0].text:
                    row.cells[1].text = nomor_surat
                elif 'Tanggal Surat Tugas' in row.cells[0].text:
                    row.cells[1].text = format_tanggal(tanggal_surat)
                elif 'Periode Penugasan' in row.cells[0].text:
                    row.cells[1].text = format_periode(periode_awal, periode_akhir)

    for table in doc.tables:
        if "No." in table.rows[0].cells[0].text:
            for i in range(len(valid_tanggal_kegiatan)):
                row = table.add_row()
                row.cells[0].text = str(i + 1)
                row.cells[1].text = format_tanggal(valid_tanggal_kegiatan[i])
                row.cells[2].text = uraian_kegiatan_list[i]
            break

    remove_empty_rows(doc)
    doc.save(word_output_path)
    
    if 'generate_pdf' in request.form:
        CoInitialize()
        word = comtypes.client.CreateObject('Word.Application')
        word.Visible = False
        doc = word.Documents.Open(word_output_path)
        doc.SaveAs(pdf_output_path, FileFormat=17)
        doc.Close()
        word.Quit()
        
    @after_this_request
    def cleanup(response):
        try:
            sleep(1)
            os.remove(word_output_path)
            if 'generate_pdf' in request.form:
                os.remove(pdf_output_path)
        except Exception as e:
            print(f"Gagal menghapus file: {e}")
        return response
    
    return send_file(pdf_output_path if 'generate_pdf' in request.form else word_output_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
