from flask import Flask, render_template, request, send_file
from docx import Document
from docx.shared import Inches
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.shared import Pt
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
TEMPLATE_FOLDER = 'templates'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Pastikan folder untuk upload ada

# Fungsi untuk membuat tabel tanda tangan
def create_signature_table(doc, ketua_tim, petugas, lokasi=None, tanggal=None):
    # Jika lokasi dan tanggal disediakan, tambahkan paragraf di atas tabel
    if lokasi and tanggal:
        paragraph = doc.add_paragraph(f"{lokasi}, {tanggal}")
        paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT  # Ratakan ke kanan

    # Tambahkan paragraf pembungkus untuk tabel
    table_paragraph = doc.add_paragraph()
    table_paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER  # Ratakan ke tengah

    # Buat tabel tanda tangan
    table = doc.add_table(rows=2, cols=2)

    # Masukkan tabel ke dalam paragraf pembungkus
    table_paragraph._p.addnext(table._tbl)

    # Masukkan teks ke dalam tabel
    table.cell(0, 0).text = "Mengetahui,\nKetua Tim Produksi\n\n\n"
    table.cell(0, 1).text = "Petugas,"
    table.cell(1, 0).text = ketua_tim
    table.cell(1, 1).text = petugas

    # Atur font dan alignment dalam tabel
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER  # Ratakan teks di tengah
                run = paragraph.runs[0]
                run.font.size = Pt(10)  # Ukuran font

    # Hilangkan garis tabel
    tbl = table._tbl
    for row in tbl.iter_tcs():
        tc_pr = row.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'none')  # Hilangkan garis
            borders.append(border)
        tc_pr.append(borders)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    # Ambil data dari form
    ketua_tim = request.form['ketua_tim']
    new_ketua_tim = request.form.get('new_ketua_tim')  # Input nama baru
    # Jika pengguna memilih untuk menambahkan nama baru
    if ketua_tim == "add_new" and new_ketua_tim:
        ketua_tim = new_ketua_tim  # Gunakan nama baru
    tanggal_laporan = request.form['tanggal_laporan']
    petugas = request.form['petugas']
    lokasi = request.form['lokasi']

    nomor_surat = request.form['nomor_surat']
    tanggal_surat = request.form['tanggal_surat']
    nama_petugas = request.form['nama_petugas']
    periode = request.form['periode']

    tanggal_kegiatan_list = request.form.getlist('tanggal_kegiatan[]')
    uraian_kegiatan_list = request.form.getlist('uraian_kegiatan[]')
    permasalahan_list = request.form.getlist('permasalahan[]')
    pemecahan_masalah_list = request.form.getlist('pemecahan_masalah[]')
    keterangan_list = request.form.getlist('keterangan[]')

    # Path template file
    template_path = os.path.join(TEMPLATE_FOLDER, 'template.docx')
    if not os.path.exists(template_path):
        return "Template file not found. Please upload the template."

    # Buka file template
    doc = Document(template_path)

    # Ganti placeholder di tabel informasi umum
    for table in doc.tables:
        if 'Nomor Surat Tugas' in table.rows[0].cells[0].text:
            for row in table.rows:
                if 'Nomor Surat Tugas' in row.cells[0].text:
                    row.cells[1].text = nomor_surat
                elif 'Tanggal Surat Tugas' in row.cells[0].text:
                    row.cells[1].text = tanggal_surat
                elif 'Nama Petugas' in row.cells[0].text:
                    row.cells[1].text = nama_petugas
                elif 'Periode Penugasan' in row.cells[0].text:
                    row.cells[1].text = periode

    # Cari tabel dengan informasi ketua tim produksi dan petugas
    for table in doc.tables:
        if 'Ketua Tim Produksi' in table.rows[-2].cells[0].text:
            for row in table.rows:
                if 'Ketua Tim Produksi' in row.cells[0].text:
                    row.cells[1].text = ketua_tim
                elif 'Petugas' in row.cells[0].text:
                    row.cells[1].text = petugas

    # Temukan tabel kegiatan dan masukkan data kegiatan
    for table in doc.tables:
        if len(table.rows) > 0 and "No." in table.rows[0].cells[0].text:
        # Tambahkan data kegiatan ke tabel
            for i in range(len(tanggal_kegiatan_list)):
            # Validasi: Pastikan data kegiatan tidak kosong
                if tanggal_kegiatan_list[i].strip() and uraian_kegiatan_list[i].strip():
                    row = table.add_row()
                    row.cells[0].text = str(i + 1)  # Nomor
                    row.cells[1].text = tanggal_kegiatan_list[i]  # Tanggal Kegiatan
                    row.cells[2].text = uraian_kegiatan_list[i]  # Uraian Kegiatan
                    row.cells[3].text = permasalahan_list[i]  # Permasalahan
                    row.cells[4].text = pemecahan_masalah_list[i]  # Pemecahan Masalah
                    row.cells[5].text = keterangan_list[i]  # Keterangan
            break
    def remove_empty_rows(doc):
    # Iterasi setiap tabel dalam dokumen
        for table in doc.tables:
            rows_to_remove = []
            for row in table.rows:
            # Periksa apakah semua sel di baris kosong
                if all(cell.text.strip() == "" for cell in row.cells):
                    rows_to_remove.append(row)

            # Hapus baris kosong yang terdeteksi
            for row in rows_to_remove:
                tbl = table._tbl
                tbl.remove(row._tr)
    
    # Tambahkan tabel tanda tangan di tengah
    create_signature_table(doc, ketua_tim=ketua_tim, petugas=petugas, lokasi=lokasi, tanggal=tanggal_laporan)

    # Tambahkan gambar jika ada
    for i in range(len(tanggal_kegiatan_list)):
        gambar_list = request.files.getlist(f'gambar_kegiatan_{i}[]')
        if gambar_list:
            doc.add_page_break()
            doc.add_paragraph(f"Dokumentasi untuk Kegiatan pada Tanggal {tanggal_kegiatan_list[i]}:")
            for gambar in gambar_list:
                if gambar.filename != '':
                    # Simpan gambar sementara
                    gambar_path = os.path.join(UPLOAD_FOLDER, gambar.filename)
                    gambar.save(gambar_path)
                    try:
                    # Tambahkan gambar ke dokumen
                        doc.add_picture(gambar_path, width=Inches(5))
                        doc.add_paragraph('Dokumentasi Kegiatan.')
                    except Exception as e:
                        print(f"Error adding image {gambar.filename}: {e}")
                    finally:
                    # Hapus file gambar setelah digunakan
                        if os.path.exists(gambar_path):
                            os.remove(gambar_path)

    remove_empty_rows(doc)

    # Simpan dokumen yang dihasilkan
    output_path = 'Laporan_Pendataan_Lapangan.docx'
    doc.save(output_path)

    # Kirim file ke pengguna
    return send_file(output_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
